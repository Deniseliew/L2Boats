import AllBoats from './Components/Allboats';

export default AllBoats;
